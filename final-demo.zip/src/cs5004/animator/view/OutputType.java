package cs5004.animator.view;

/**
 * OutputType.
 */
public enum OutputType {
  SVG,
  TEXT
}
